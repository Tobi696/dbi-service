package com.waterbyte.servicebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicebackendApplication.class, args);
	}

}
