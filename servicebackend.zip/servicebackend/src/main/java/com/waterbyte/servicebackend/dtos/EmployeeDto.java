package com.waterbyte.servicebackend.dtos;

import lombok.Data;

@Data
public class EmployeeDto {
    private String name;
    private String latitude;
    private String longitude;
}
